# Change Log

All notable changes to the "allyson" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [Unreleased]

## [0.2.2][] - 2024-05-29

### Added
- `precision` keyword

## [0.2.1][] - 2024-05-21

### Added
- Prompt to reload window after extension update

## [0.2.0][] - 2024-05-21

### Added
- Check for updates on startup.
- Output channel to vscode.

## [0.1.1][] - 2024-05-20

### Added

- Keywords:
    - random
    - noseed
    - tbrotate
    - mpinclude
    - mpexclude

## [0.1.0][] - 2024-05-20

- Initial release


[Unreleased]: http://gitlab.int-research.com/general/vscode-alysson/compare/v0.2.2...main
[0.2.2]: http://gitlab.int-research.com/general/vscode-alysson/compare/v0.2.1...v0.2.2
[0.2.1]: http://gitlab.int-research.com/general/vscode-alysson/compare/v0.2.0...v0.2.1
[0.2.0]: http://gitlab.int-research.com/general/vscode-alysson/compare/v0.1.1...v0.2.0
[0.1.1]: http://gitlab.int-research.com/general/vscode-alysson/compare/v0.1.0...v0.1.1
[0.1.0]: http://gitlab.int-research.com/general/vscode-alysson/tags/v0.1.0
